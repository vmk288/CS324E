open the .pde file and press Play. You may have to click the canvas with the mouse before pressing any of the numbers for 
the filter to show up. 
Press 0 for Original Image
	  1 for Gray Scale
	  2 for Contrast
	  3 for Gaussian Blur
	  4 for Edge Detection/Sobel
	  
