1. Run extract_words.py in the terminal. This will generate allwords.txt, unique_words.txt, and wordfrequency.txt.
2. unique_words.txt will already be in a3_novelvisualization directory, but can be copied over into the a3_novelvisualization directory and replaced. 
3. Open a3_novelvisualization.pde and press play for word cloud. Clicking the canvas will change words. 
4. wordfrequency.txt will already be in a3_wordfrequency directory, but can be copied over into the a3_wordfrequency directory and replaced.
5. Open a3_wordfrequency.pde and press play for frequency visualization. Graph will appear in a red color and automatically change to different colors until it lastly appears in a baby blue color