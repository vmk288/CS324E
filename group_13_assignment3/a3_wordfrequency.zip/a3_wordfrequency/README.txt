README

Danish Tharvani

How to Run this Program

1. Open 'a3_wordfrequency.pde' file
2. Click the 'Play' button in the top left corner to start the processing graph
3. Graph will appear in a red color and automatically change to different colors until it lastly appears in a baby blue color