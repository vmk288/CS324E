1. Open .pde file called group_13_assignment4. The corresponding object classes will open automatically.
2. Click "play" to start animation.
3. Animation will continue to loop until the window is closed. 

Note: for the music to play, the computer must have the Minim library installed on the computer. 

If sound does not work:
1. Exit out of display window 
2. Comment out lines 1-5 and 21-23. 
3. Replay the animation using the same steps as above